

  var abc = document.getElementById("comment");



function myFunction() {
    $("#list_add").append("<li>"+abc.value+"</li>"); 

  }

